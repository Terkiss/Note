package com.example.android_test_02;

public class LoginActivity {
}
